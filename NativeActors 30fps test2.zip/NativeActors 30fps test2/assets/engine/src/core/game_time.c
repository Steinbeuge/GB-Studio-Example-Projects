#include "game_time.h"

UINT8 game_time = 0;
