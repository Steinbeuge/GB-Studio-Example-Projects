#ifndef STATE_SHMUP_H
#define STATE_SHMUP_H

#include <gbdk/platform.h>

void shmup_init(void) BANKED;
void shmup_update(void) BANKED;

#endif
