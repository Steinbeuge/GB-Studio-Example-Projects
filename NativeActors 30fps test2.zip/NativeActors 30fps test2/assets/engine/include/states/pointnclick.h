#ifndef STATE_POINT_N_CLICK_H
#define STATE_POINT_N_CLICK_H

#include <gbdk/platform.h>

void pointnclick_init(void) BANKED;
void pointnclick_update(void) BANKED;

#endif
